WELCOME TO THE AGCEEP
Bundled version with "For the Glory"

#-----------------------------------------------------------------------------------------------

We are trying to make the best mod we can focusing on History, alternative history and gameplay... not necessarily in that order.

Options:

Once you start the AGCEEP you can then select a scenario.  We have the 1419, 1520 and 1648 scenario and a special fantasy Byzantium scenario.

Once you select a scenario you will then be presented with more options than the standard EU2 game.

Use Random events:
  If clicked NO, this option will disable the use of the AGCEEP Random events.  In their place you will receive "commercials" advertising features of the AGCEEP.  These commercials are unavoidable and cannot be gotten rid of, since the game needs random events to run.

Alternative Events:
  If clicked YES, then certain Fantasy events will be enabled that will allow the formation of the Kingdom of Germany, the formation of the Kingdom of Italy, an Independent Wales, and a new crusade by the Order of St. John and England.

#-----------------------------------------------------------------------------------------------

The High Council are the users designated with compiling and curating the AGCEEP. They are: 

Twoflower
doktarr
Mad King James
ribbon22
Garbon
Sun_Zi_36
Norrefeldt
dharper
YodaMaster
Fodoron
mandead
ConjurerDragon

Additional HC members may be voted in by consensus of current active members.

#-----------------------------------------------------------------------------------------------

Thanks to contributors/authors of events, leaders and monarchs for previous versions:

Annibale, tpc, Atremis667, Pishtaco, Korath, Isaac Brock, Johan Andersson, Zenek K, Jinnai,
H�vard Moe, Bash, Isengard, Khephren, Tom 'Demetrios' Rinschler, Henrik 'Doomdark' F�hraeus,
Joakim 'Greven' Bergqwist, Chanda "Philip V" Choun, Thomas 'Besuchov' Johansson, Marc Figueras,
lozanof, LP2le_retour, Cat Lord, Crook, driftwood, chegitz guevara, AlanC9, Voivode, Lambert Simnel,
Archeolooginspe, Stefan Huszics, Kristof 'BiB' Haekens, Petter 'Carolus Rex' Carnbro, TheF,
zacharym87, Herr Doctor, Kelvin, Sute]{h, Ryan, William 'State Machine' Thomas, Count Six, Fate,
Belissarius, RepublicofGenoa, suo, Pwyll, gnome, JG1Beck, Mosschops, Richard IV, St. Leo, Sheridan,
John_Keats, Ryoken69, Johnny Canuck, Steph, Jessums, Artemis667, Third Angel, Praetor, Captain Krunch,
Dracleath, Aetius, Neuromancer, Suleyman, Aylo1, Laur, Wido, Bordic, Alkar, Yarovit, Greebo, Emre Yigit,
Malodini, Chimera, btg, nelly664, George Borges, Raudex, Wiande, Aegnor, Solmyr, BarristerBoy, Andravius,
Toio, Todor, Yacine Gouaref (cpt frakas), Kasperus, George Borges, Zius, zBla, Txini, Maulet, Chema_Cagi,
Moragues, Xaloc, Sulayman, Barbalele, Jan Zamojsky, Jester, Ayeshteni, vjwua, others, and all HC members!
